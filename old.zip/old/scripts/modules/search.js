class SearchModule extends Module {
  constructor(notes, listControls) {
    super();

    this.element = document.createElement('input');
    this.listControls = listControls;
    this.notes = notes;
  }

  start() {
    // this.searchMode.value = localStorage.searching;
    // this.searchMode.input.value = this.searchMode.value;

    this.element = document.createElement('input');

    this.element.type = 'text';
    this.element.className = 'search-notes';
    this.element.placeholder = 'Enter keyword';
    this.element.maxLength = 30;

    for (var i = 0; i < this.notes.length; i++) {
      const item = this.notes[i].self;

      this.lock(item);
    }
    
    this.listControls.appendChild(this.element);
    this.element.focus();

    this.events = {
      oninput: this._inputhandler.bind(this),
      onkeyup: this._keyuphandler.bind(this),
      onblur: this._blurhandler.bind(this),
    };

    document.addEventListener('input', this.events.oninput);
    document.addEventListener('keyup', this.events.onkeyup);
    document.addEventListener('blur', this.events.onblur);

    this._busy = true;
  }

  search() {
    var key = this.value.toLowerCase();

    for (var i = 0; i < this.notes.length; i++) {
      const item = this.notes[i];

      item.self.style.display = this.matched(key, item) ? '' : 'none';
    }
  }

  focus() {
    this.element.focus();
  }

  lock(item) {
    item.sortButton.disabled = true;
    item.sortButton.setAttribute('disabled', 'disabled');
  }

  complete() {
    document.removeEventListener('input', this.events.oninput);
    document.removeEventListener('keyup', this.events.onkeyup);
    document.removeEventListener('blur', this.events.blur);
  
    this.listControls.removeChild(this.element);
    // localStorage.removeItem('searching');
  
    for (var i = 0; i < this.notes.length; i++) {
      const item = this.notes[i];
  
      item.self.sortButton.disabled = false;
      item.self.sortButton.removeAttribute('disabled');
    }

    this.element = null;
    this.events = null;

    this._busy = true;
  }

  matched(key, item) {
    var t_index = item.title.toLowerCase().indexOf(key);
    var d_index = item.description.toLowerCase().indexOf(key);
  
    return (t_index !== -1 || d_index !== -1);
  }

  _cancel() {
    for (var i = 0; i < this.notes.length; i++) {
      this.notes[i].self.style.display = '';
    }
  }

  _inputhandler(){
    this.value = this.element.value.trim();

    if (this.value.length > 0) {
      this.search();
    } else {
      this._cancel();
    }
  
    // localStorage.searching = this.searchMode.value;
  }

  _keyuphandler(e){
    e.preventDefault();

    if (e.keyCode == 27) {
      this._cancel();
      this.complete();
      return false;
    }
  }

  _blurhandler(e) {
    if (this.searchMode.input.value.trim().length === 0) {
      this.complete();
    }
  }
}
